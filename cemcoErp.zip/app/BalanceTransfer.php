<?php namespace App;
use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Support\Facades\DB;

class BalanceTransfer extends Eloquent
{
    protected $table = 'balance_transfers';

}