<?php namespace App;
use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Support\Facades\DB;

class TTCharge extends Eloquent
{
    protected $table = 'tt_charges';


}