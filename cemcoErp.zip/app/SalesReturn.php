<?php namespace App;
use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Support\Facades\DB;

class SalesReturn extends Eloquent
{
    protected $table = 'sales_return';
}